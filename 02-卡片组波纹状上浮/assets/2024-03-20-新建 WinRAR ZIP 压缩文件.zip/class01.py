a = 46
print(a)
b = 20
print(b)
print('a|b - ', a|b)
print('a|b - ', a&b)
print('a|b - ', a^b)
print('a|b - ', ~a)
print('a|b - ', a>>2)
print('a|b - ', a<<2)
