from random import *
#100奇数和
print("1 - 100奇数和")
sum = 0
for i in range(1,100,2):
    sum+=i;
print(sum)
#水仙花数
print("2 - 三位水仙花数")
for i in range(100,1000):
    if(int(i%1000/100)**3+int(i%100/10)**3+int(i%10)**3 == i):
        print(i)
#验证码
print("3 - 验证码")
str = '0123456789qwertyuiopasdfghjklzxcvbnm'
arr = [0,1,2,3,4]
for i in range(1,5):
    arr[i] = choice(str)
print("{}{}{}{}{}".format(arr[0],arr[1],arr[2]))
